# 免费小说阅读器

### 使用源码请先star一下。

### 项目介绍

* 全网免费小说，功能齐全，书架、分类、各大排行榜，搜索、详情页，评论、阅读、夜间模式，字体大小，目录。

* 小说是自动更新的，数据来源第三方API，无依赖库。

* 学习到的东西很多，强大的文字排版功能。

* 搜索，分类，排行榜的可以点击添加到书架。

* 只需 要修改小程序appid和在小程序公众号中添加服务器域名（开发工具有添加域名提示），就可以发布小程序了。

* 使用问题咨询QQ：903363777

### 项目运行截图

![](https://bmob-cdn-19897.bmobcloud.com/2019/06/12/c10138d24014765f8057d9091c49a580.jpg)

![](https://bmob-cdn-19897.bmobcloud.com/2019/06/12/cb45b4b8400cf33680f0ea21deffbf8d.jpg)

![](https://bmob-cdn-19897.bmobcloud.com/2019/06/12/848dfa0740e239b9805ef750dc7c88e7.jpg)

![](https://bmob-cdn-19897.bmobcloud.com/2019/06/12/4971533c40076a9c80ae2ca353f284eb.jpg)

![](https://bmob-cdn-19897.bmobcloud.com/2019/06/12/92534a3d40efb3e5802a84ffb155aee1.jpg)

### 小程序二维码

![](https://bmob-cdn-19897.bmobcloud.com/2019/06/12/d72e06b44050e8f380e4151bf677dfc9.jpg)
